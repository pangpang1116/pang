local basestatmod = RegisterMod("custom base stats", 1);

local defaultdamage = 3.5
local defaultteardelay = 10
local defaultrange = 23.75
local defaultshotspeed = 1
local defaultmovespeed = 1
local defaultluck = 0

local basedamage = defaultdamage
local baseteardelay = defaultteardelay
local baserange = defaultrange
local baseshotspeed = defaultshotspeed
local basemovespeed = defaultmovespeed
local baseluck = defaultluck

local CharacterNames = {"Isaac","Magdalene","Cain","Judas","???","Eve","Samson","Azazel","Lazarus","Eden","Lost","Lazarus2","Dark Judas","Lilith","Keeper","Apollyon","Forgotten","Soul"}

local CharacterEnabled = {"F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F"}

local defaultDamageMultiplier = {1,1,1.2,1.35,1.05,0.75,1,1.5,1,1,1,1.2,2,1,1.2,1,1.5,1}
local defaultCharacterTearRate = {}
local defaultCharacterRange = {}
local samsonShotSpeed = 1.31
local defaultCharacterMoveSpeed = {}
local lazarusLuck = -1
local keeperLuck = -2

local DamageMultiplier = {}
local CharacterDamage = {}
local CharacterTearRate = {}
local CharacterRange = {}
local CharacterShotSpeed = {}
local CharacterMoveSpeed = {}
local CharacterLuck = {}

for i = 1, 18, 1 do
	--get default values for characters
	defaultCharacterTearRate[i] = defaultteardelay
	if CharacterNames[i] == "Samson" then
		defaultCharacterTearRate[i] = 11
	elseif CharacterNames[i] == "Azazel" then
		defaultCharacterTearRate[i] = 30
	elseif CharacterNames[i] == "Keeper" then
		defaultCharacterTearRate[i] = 28
	elseif CharacterNames[i] == "Forgotten" then
		defaultCharacterTearRate[i] = 20
	end
	defaultCharacterRange[i] = defaultrange
	if CharacterNames[i] == "Cain" then
		defaultCharacterRange[i] = 17.75
	elseif CharacterNames[i] == "Samson" then
		defaultCharacterRange[i] = 18.75
	elseif CharacterNames[i] == "Azazel" then
		defaultCharacterRange[i] = 17.75
	end
	defaultCharacterMoveSpeed[i] = defaultmovespeed
	if CharacterNames[i] == "Magdalene" or CharacterNames[i] == "Keeper" then
		defaultCharacterMoveSpeed[i] = 0.85
	elseif CharacterNames[i] == "Cain" or CharacterNames[i] == "Soul" then
		defaultCharacterMoveSpeed[i] = 1.3
	elseif CharacterNames[i] == "Dark Judas" or CharacterNames[i] == "???" or CharacterNames[i] == "Samson" then
		defaultCharacterMoveSpeed[i] = 1.1
	elseif CharacterNames[i] == "Eve" then
		defaultCharacterMoveSpeed[i] = 1.23
	elseif CharacterNames[i] == "Azazel" or CharacterNames[i] == "Lazarus2" then
		defaultCharacterMoveSpeed[i] = 1.25
	end
	
	--create stat tables
	DamageMultiplier[i] = defaultDamageMultiplier[i]
	CharacterDamage[i] = defaultdamage
	CharacterTearRate[i] = defaultCharacterTearRate[i]
	CharacterRange[i] = defaultCharacterRange[i]
	CharacterShotSpeed[i] = defaultshotspeed
	if CharacterNames[i] == "Samson" then
		CharacterShotSpeed[i] = samsonShotSpeed
	end
	CharacterMoveSpeed[i] = defaultCharacterMoveSpeed[i]
	CharacterLuck[i] = defaultluck
	if CharacterNames[i] == "Lazarus" then
		CharacterLuck[i] = lazarusLuck
	elseif CharacterNames[i] == "Keeper" then
		CharacterLuck[i] = keeperLuck
	end
end


function basestatmod:PostPlayerInit(player)
	basestatmod:loadbasestatdata()
end

--apply stat adjustments
function basestatmod:update(player, cacheFlag)
	local playerID = player:GetPlayerType()+1
	local multiplier = 1
	local damagestat = basedamage
	local firedelaystat = baseteardelay
	local rangestat = baserange
	local shotspeedstat = baseshotspeed
	local movespeedstat = basemovespeed
	local luckstat = baseluck
	--use default stats for modded characters
	local premultiplier = 1
	local pretearrate = defaultteardelay
	local prerange = defaultrange
	local prespeed = defaultmovespeed
	if playerID < 19 then --ignore modded characters when handling saved settings
		--get character specific stats
		if CharacterEnabled[playerID] == "T" then
			premultiplier = defaultDamageMultiplier[playerID]
			pretearrate = defaultCharacterTearRate[playerID]
			prerange = defaultCharacterRange[playerID]
			prespeed = defaultCharacterMoveSpeed[playerID]
			multiplier = DamageMultiplier[playerID]
			damagestat = CharacterDamage[playerID]
			firedelaystat = CharacterTearRate[playerID]
			rangestat = CharacterRange[playerID]
			shotspeedstat = CharacterShotSpeed[playerID]
			movespeedstat = CharacterMoveSpeed[playerID]
			luckstat = CharacterLuck[playerID]
		end
	end
	--update stats
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		local nonbasedamage = player.Damage/premultiplier - defaultdamage
		player.Damage = (nonbasedamage+damagestat)*multiplier
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		player.MaxFireDelay = player.MaxFireDelay - pretearrate + firedelaystat
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		player.TearHeight = player.TearHeight + prerange - rangestat
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if playerID < 19 and CharacterNames[playerID] == "Samson" and CharacterEnabled[playerID] == "T" then
			player.ShotSpeed = player.ShotSpeed - samsonShotSpeed + shotspeedstat
		else
			player.ShotSpeed = player.ShotSpeed - defaultshotspeed + shotspeedstat
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		player.MoveSpeed = player.MoveSpeed - prespeed + movespeedstat
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if playerID < 19 and CharacterNames[playerID] == "Lazarus" and CharacterEnabled[playerID] == "T" then
			player.Luck = player.Luck - lazarusLuck + luckstat 
		elseif playerID < 19 and CharacterNames[playerID] == "Keeper" and CharacterEnabled[playerID] == "T" then
			player.Luck = player.Luck - keeperLuck + luckstat
		else
			player.Luck = player.Luck + luckstat
		end
	end
end

--let player set base stats in console
function basestatmod:onCmd(cmd, param)
	local temp = tonumber(param)
	if cmd == "basedamagestat" then
		if temp then
			basedamage = temp
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Damage stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "baseteardelaystat" then
		if temp then
			baseteardelay = math.floor(temp)
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Teardelay stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "baserangestat" then
		if temp then
			baserange = temp
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Range stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "baseshotspeedstat" then
		if temp then
			baseshotspeed = temp
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Shot speed stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "basemovespeedstat" then
		if temp then
			basemovespeed = temp
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Move speed stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "baseluckstat" then
		if temp then
			baseluck = temp
			basestatmod:savebasestatdata()
			Isaac.ConsoleOutput("Luck stat updated")
		else
			Isaac.ConsoleOutput("Please enter a valid number")
		end
	end
	if cmd == "resetbasestats" then
		basedamage = defaultdamage
		baseteardelay = defaultteardelay
		baserange = defaultrange
		baseshotspeed = defaultshotspeed
		basemovespeed = defaultmovespeed
		baseluck = defaultluck
		basestatmod:savebasestatdata()
		Isaac.ConsoleOutput("Base stats reset")
	end
	if cmd == "viewbasestats" then
		Isaac.ConsoleOutput("Current base stats")
		Isaac.ConsoleOutput("Damage " .. basedamage)
		Isaac.ConsoleOutput("Teardelay " .. baseteardelay)
		Isaac.ConsoleOutput("Range " .. baserange)
		Isaac.ConsoleOutput("Shotspeed " .. baseshotspeed)
		Isaac.ConsoleOutput("Movespeed " .. basemovespeed)
		Isaac.ConsoleOutput("Luck " .. baseluck)
	end
end


--convert data for loading
function basestatmod:loadbasestatdata()
	local str = Isaac.LoadModData(basestatmod)
	local section = 0
	local character = -1
	local multiplierstring = ""
	local damagestring = ""
	local teardelaystring = ""
	local rangestring = ""
	local shotspeedstring = ""
	local movespeedstring = ""
	local luckstring = ""
	for i = 1, string.len(str), 1 do
		local substring = string.sub(str, i, i)
		if substring == "~" then
			if character == 0 then
				basedamage = tonumber(damagestring)
				baseteardelay = tonumber(teardelaystring)
				baserange = tonumber(rangestring)
				baseshotspeed = tonumber(shotspeedstring)
				basemovespeed = tonumber(movespeedstring)
				baseluck = tonumber(luckstring)
			elseif character > 0 then
				DamageMultiplier[character] = tonumber(multiplierstring)
				CharacterDamage[character] = tonumber(damagestring)
				CharacterTearRate[character] = tonumber(teardelaystring)
				CharacterRange[character] = tonumber(rangestring)
				CharacterShotSpeed[character] = tonumber(shotspeedstring)
				CharacterMoveSpeed[character] = tonumber(movespeedstring)
				CharacterLuck[character] = tonumber(luckstring)
			end
			character = character + 1
			section = 0
			multiplierstring = ""
			damagestring = ""
			teardelaystring = ""
			rangestring = ""
			shotspeedstring = ""
			movespeedstring = ""
			luckstring = ""
		else
			if substring == "#" then
				section = section + 1
			else
				if section == 0 and character > 0 then
					CharacterEnabled[character] = substring
				elseif section == 1 then
					multiplierstring = multiplierstring .. substring
				elseif section == 2 then
					damagestring = damagestring .. substring
				elseif section == 3 then
					teardelaystring = teardelaystring .. substring
				elseif section == 4 then
					rangestring = rangestring .. substring
				elseif section == 5 then
					shotspeedstring = shotspeedstring .. substring
				elseif section == 6 then
					movespeedstring = movespeedstring .. substring
				elseif section == 7 then
					luckstring = luckstring .. substring
				end
			end
		end
	end
	if string.len(str) < 9 then
		basedamage = defaultdamage
		baseteardelay = defaultteardelay
		baserange = defaultrange
		baseshotspeed = defaultshotspeed
		basemovespeed = defaultmovespeed
		baseluck = defaultluck
	end
	basestatmod:savebasestatdata()
end
--convert data for saving
function basestatmod:savebasestatdata()
	local str = ""
	str = str .. "~"
	str = str .. "D"
	str = str .. "#"
	str = str .. "1"
	str = str .. "#"
	str = str .. basedamage
	str = str .. "#"
	str = str .. baseteardelay
	str = str .. "#"
	str = str .. baserange
	str = str .. "#"
	str = str .. baseshotspeed
	str = str .. "#"
	str = str .. basemovespeed
	str = str .. "#"
	str = str .. baseluck
	for i = 1, 18, 1 do
		str = str .. "~"
		str = str .. CharacterEnabled[i]
		str = str .. "#"
		str = str .. DamageMultiplier[i]
		str = str .. "#"
		str = str .. CharacterDamage[i]
		str = str .. "#"
		str = str .. CharacterTearRate[i]
		str = str .. "#"
		str = str .. CharacterRange[i]
		str = str .. "#"
		str = str .. CharacterShotSpeed[i]
		str = str .. "#"
		str = str .. CharacterMoveSpeed[i]
		str = str .. "#"
		str = str .. CharacterLuck[i]
	end
	str = str .. "~"
	Isaac.SaveModData(basestatmod, str)
end

--mod config menu stuff
local resetstats = false
if ModConfigMenu then
	--default stat settings
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return basedamage
		end,
		Minimum = 0,
		ModifyBy = 0.1,
		Display = function()
			return "Damage: " .. basedamage
		end,
		OnChange = function(currentNum)
			basedamage = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base damage stat. (3.5 default)"
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return baseteardelay
		end,
		Minimum = 0,
		Display = function()
			return "Tear delay: " .. baseteardelay
		end,
		OnChange = function(currentNum)
			baseteardelay = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base tear delay. (10 default)"
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return baserange
		end,
		ModifyBy = 0.1,
		Display = function()
			return "Range: " .. baserange
		end,
		Minimum = 0,
		OnChange = function(currentNum)
			baserange = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base range stat. (23.75 default)"
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return baseshotspeed
		end,
		Minimum = 0,
		ModifyBy = 0.1,
		Display = function()
			return "Shot speed: " .. baseshotspeed
		end,
		OnChange = function(currentNum)
			baseshotspeed = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base shot speed stat. (1 default)"
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return basemovespeed
		end,
		Minimum = 0,
		ModifyBy = 0.1,
		Display = function()
			return "Move speed: " .. basemovespeed
		end,
		OnChange = function(currentNum)
			basemovespeed = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base move speed stat. (1 default)"
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.NUMBER,
		CurrentSetting = function()
			return baseluck
		end,
		ModifyBy = 0.1,
		Display = function()
			return "Luck: " .. baseluck
		end,
		OnChange = function(currentNum)
			baseluck = currentNum
			basestatmod:savebasestatdata()
		end,
		Info = {
			"Base luck stat. (0 default)"
		}
	})
	ModConfigMenu.AddSpace("Base Stats","Default")
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.BOOLEAN,
		CurrentSetting = function()
			return resetstats
		end,
		Display = function()
			return "RESET DEFAULT BASE STATS"
		end,
		OnChange = function(currentBool)
			resetstats = currentBool
			basedamage = defaultdamage
			baseteardelay = defaultteardelay
			baserange = defaultrange
			baseshotspeed = defaultshotspeed
			basemovespeed = defaultmovespeed
			baseluck = defaultluck
			basestatmod:savebasestatdata()
			resetstats = false
		end,
		Info = {
			"Reset default base stats."
		}
	})
	ModConfigMenu.AddSetting("Base Stats","Default", { 
		Type = ModConfigMenuOptionType.BOOLEAN,
		CurrentSetting = function()
			return resetstats
		end,
		Display = function()
			return "RESET ALL BASE STATS"
		end,
		OnChange = function(currentBool)
			resetstats = currentBool
			basedamage = defaultdamage
			baseteardelay = defaultteardelay
			baserange = defaultrange
			baseshotspeed = defaultshotspeed
			basemovespeed = defaultmovespeed
			baseluck = defaultluck
			CharacterEnabled = {"F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F","F"}
			for i = 1, 18, 1 do
				DamageMultiplier[i] = defaultDamageMultiplier[i]
				CharacterDamage[i] = defaultdamage
				CharacterTearRate[i] = defaultCharacterTearRate[i]
				CharacterRange[i] = defaultCharacterRange[i]
				CharacterShotSpeed[i] = defaultshotspeed
				if CharacterNames[i] == "Samson" then
					CharacterShotSpeed[i] = samsonShotSpeed
				end
				CharacterMoveSpeed[i] = defaultCharacterMoveSpeed[i]
				CharacterLuck[i] = defaultluck
				if CharacterNames[i] == "Lazarus" then
					CharacterLuck[i] = lazarusLuck
				elseif CharacterNames[i] == "Keeper" then
					CharacterLuck[i] = keeperLuck
				end
			end
			basestatmod:savebasestatdata()
			resetstats = false
		end,
		Info = {
			"Reset ALL base stats,",
			"includes default and character stats."
		}
	})
	--Character stat settings
	for i = 1, 18, 1 do
		local defaultshotspeeddisplay = 1
		if CharacterNames[i] == "Samson" then
			defaultshotspeeddisplay = samsonShotSpeed
		end
		local defaultluckdisplay = 0
		if CharacterNames[i] == "Lazarus" then
			defaultluckdisplay = lazarusLuck
		elseif CharacterNames[i] == "Keeper" then
			defaultluckdisplay = keeperLuck
		end
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.BOOLEAN,
			CurrentSetting = function()
				return (CharacterEnabled[i] == "T")
			end,
			Display = function()
				local onOff = "OFF"
				if CharacterEnabled[i] == "T" then
					onOff = "ON"
				end
				return "Base Stats for " .. CharacterNames[i] .. " " .. onOff
			end,
			OnChange = function(currentBool)
				if currentBool then
					CharacterEnabled[i] = "T"
				else
					CharacterEnabled[i] = "F"
				end
				basestatmod:savebasestatdata()
			end,
			Info = {
				"Enable Base Stats specific to " .. CharacterNames[i] .. "."
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return DamageMultiplier[i]
			end,
			Minimum = 0.1,
			ModifyBy = 0.1,
			Display = function()
				return "Damage Multiplier: " .. DamageMultiplier[i]
			end,
			OnChange = function(currentNum)
				DamageMultiplier[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Damage Multiplier. (" .. defaultDamageMultiplier[i] .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterDamage[i]
			end,
			Minimum = 0,
			ModifyBy = 0.1,
			Display = function()
				return "Damage: " .. CharacterDamage[i]
			end,
			OnChange = function(currentNum)
				CharacterDamage[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base damage stat. (3.5 default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], {
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterTearRate[i]
			end,
			Minimum = 0,
			Display = function()
				return "Tear delay: " .. CharacterTearRate[i]
			end,
			OnChange = function(currentNum)
				CharacterTearRate[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base tear delay. (" .. defaultCharacterTearRate[i] .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterRange[i]
			end,
			ModifyBy = 0.1,
			Display = function()
				return "Range: " .. CharacterRange[i]
			end,
			Minimum = 0,
			OnChange = function(currentNum)
				CharacterRange[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base range stat. (" .. defaultCharacterRange[i] .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterShotSpeed[i]
			end,
			Minimum = 0,
			ModifyBy = 0.1,
			Display = function()
				return "Shot speed: " .. CharacterShotSpeed[i]
			end,
			OnChange = function(currentNum)
				CharacterShotSpeed[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base shot speed stat. (" .. defaultshotspeeddisplay .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterMoveSpeed[i]
			end,
			Minimum = 0,
			ModifyBy = 0.1,
			Display = function()
				return "Move speed: " .. CharacterMoveSpeed[i]
			end,
			OnChange = function(currentNum)
				CharacterMoveSpeed[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base move speed stat. (" .. defaultCharacterMoveSpeed[i] .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.NUMBER,
			CurrentSetting = function()
				return CharacterLuck[i]
			end,
			ModifyBy = 0.1,
			Display = function()
				return "Luck: " .. CharacterLuck[i]
			end,
			OnChange = function(currentNum)
				CharacterLuck[i] = currentNum
				basestatmod:savebasestatdata()
			end,
			Info = {
				CharacterNames[i] .. "'s Base luck stat. (" .. defaultluckdisplay .. " default)"
			}
		})
		ModConfigMenu.AddSetting("Base Stats", CharacterNames[i], { 
			Type = ModConfigMenuOptionType.BOOLEAN,
			CurrentSetting = function()
				return resetstats
			end,
			Display = function()
				return "RESET " .. CharacterNames[i] .. "'s base stats"
			end,
			OnChange = function(currentBool)
				resetstats = currentBool
				CharacterEnabled[i] = "F"
				DamageMultiplier[i] = defaultDamageMultiplier[i]
				CharacterDamage[i] = defaultdamage
				CharacterTearRate[i] = defaultCharacterTearRate[i]
				CharacterRange[i] = defaultCharacterRange[i]
				CharacterShotSpeed[i] = defaultshotspeed
				if CharacterNames[i] == "Samson" then
					CharacterShotSpeed[i] = samsonShotSpeed
				end
				CharacterMoveSpeed[i] = defaultCharacterMoveSpeed[i]
				CharacterLuck[i] = defaultluck
				if CharacterNames[i] == "Lazarus" then
					CharacterLuck[i] = lazarusLuck
				elseif CharacterNames[i] == "Keeper" then
					CharacterLuck[i] = keeperLuck
				end
				basestatmod:savebasestatdata()
				resetstats = false
			end,
			Info = {
				"Reset base stats to the default values."
			}
		})
	end
end

basestatmod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, basestatmod.PostPlayerInit);
basestatmod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE , basestatmod.update);
basestatmod:AddCallback(ModCallbacks.MC_EXECUTE_CMD, basestatmod.onCmd);







local mod = RegisterMod("custom base stats", 1)

function mod:startRun()
Isaac.ExecuteCommand("debug 3")
Isaac.ExecuteCommand("debug 10")
end
mod:AddCallback( ModCallbacks.MC_POST_GAME_STARTED, mod.startRun)

function mod:OnPostNewLevel()
Game():GetLevel():ShowMap()
end

mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, mod.OnPostNewLevel)

function mod:PostUpdate()
if Game():GetLevel():GetStage() then
 Game():GetLevel():RemoveCurses()
 end
 end
 
 mod:AddCallback(ModCallbacks.MC_POST_UPDATE, mod.PostUpdate)

